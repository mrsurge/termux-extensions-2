# Step 6 — Generic Apps Extension Integration (Manifest → Shell → Assets → Lifecycle)

**Goal:** Provide one **apps extension backend** that lists apps from `app/apps/`, serves their assets, renders the full‑screen app shell, and exposes a **lifecycle hook** so the UI can cascade‑terminate child shells when the app view closes — without any app‑specific code.

> This step assumes Steps 1–5 are in place (safe loaders, optional imports, worker fallback, jobs, and shell grouping helpers).

---

## 1) Backend blueprint for the Apps extension

Create/replace the extension backend at: `app/extensions/apps/main.py`

```python
# app/extensions/apps/main.py
from __future__ import annotations
from flask import Blueprint, current_app, jsonify, render_template, send_from_directory, abort
import os, json, importlib.util, traceback
from pathlib import Path

bp = Blueprint("apps_ext", __name__)

def _apps_dir() -> Path:
    app_root = Path(current_app.root_path).resolve()
    default_apps = (app_root / "apps").resolve()
    cfg = current_app.config.get("APPS_DIR")
    return Path(cfg).resolve() if cfg else default_apps

def _register_backend_if_any(app_id: str, app_dir: Path, backend_file: str, errs: list[str]) -> None:
    # Avoid double registration across reloads
    reg = current_app.config.setdefault("TE_REGISTERED_APP_IDS", set())
    if app_id in reg:
        return
    backend_path = (app_dir / backend_file).resolve()
    if not backend_path.exists():
        errs.append(f"backend missing: {backend_file}")
        return
    module_name = f"app.apps.{app_dir.name}.{backend_path.stem}"
    try:
        spec = importlib.util.spec_from_file_location(module_name, str(backend_path))
        if not spec or not spec.loader:
            raise ImportError(f"spec not found for {backend_path}")
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
    except BaseException as e:
        errs.append(f"import failed: {type(e).__name__}: {e}")
        errs.append(traceback.format_exc()[-512:])
        return

    from flask import Blueprint as _BP
    for name in dir(module):
        obj = getattr(module, name)
        if isinstance(obj, _BP):
            try:
                current_app.register_blueprint(obj, url_prefix=f"/api/app/{app_id}")
                reg.add(app_id)
            except BaseException as e:
                errs.append(f"register failed: {type(e).__name__}: {e}")
                errs.append(traceback.format_exc()[-512:])
            break
    else:
        errs.append("no Flask Blueprint exported in backend module")

def _collect_apps() -> list[dict]:
    base = _apps_dir()
    results: list[dict] = []
    if not base.exists():
        return results
    for child in sorted(base.iterdir()):
        if not child.is_dir():
            continue
        manifest_path = child / "manifest.json"
        if not manifest_path.exists():
            continue
        entry = {"_dir": child.name}
        try:
            manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        except Exception as e:
            entry.update({"id": child.name, "name": child.name, "__load_error__": f"Bad manifest: {e}"})
            results.append(entry); continue
        app_id = manifest.get("id") or child.name
        entry.update({
            "id": app_id,
            "name": manifest.get("name") or app_id,
            "description": manifest.get("description"),
            "icon_emoji": manifest.get("icon_emoji"),
            "entrypoints": manifest.get("entrypoints", {}),
        })
        backend = (entry["entrypoints"] or {}).get("backend_blueprint")
        if backend:
            errs: list[str] = []
            _register_backend_if_any(app_id, child, backend, errs)
            if errs: entry["__load_error__"] = "; ".join(errs)
        results.append(entry)
    return results

@bp.get("/api/apps")
def api_apps():
    return jsonify(ok=True, data=_collect_apps())

@bp.get("/apps/<app_dir>/<path:filename>")
def serve_app_asset(app_dir: str, filename: str):
    base = _apps_dir().resolve()
    app_path = (base / app_dir).resolve()
    if not app_path.exists() or not str(app_path).startswith(str(base)): abort(404)
    target = (app_path / filename).resolve()
    if not target.exists() or not str(target).startswith(str(app_path)): abort(404)
    return send_from_directory(app_path, filename)

@bp.get("/app/<app_id>")
def app_shell(app_id: str):
    return render_template("app_shell.html", app_id=app_id)
```

- **/api/apps** returns the manifest list with `_dir` and `entrypoints` fields used by your launcher and app shell.
- **/apps/<dir>/** serves per‑app assets (`template.html`, `main.js`, etc.).
- **/app/<id>** renders the shell frame (`app/templates/app_shell.html`).

---

## 2) Lifecycle: terminate a whole app group on close

In **Step 5** you added a tiny helper and an admin route to terminate a group. Reuse it here: when the app view unloads, POST the group string to that route.

Edit `app/templates/app_shell.html` and add this minimal JS near the bottom:

```html
<script>
(() => {
  const appId = "{{ app_id }}";
  // Stable per-view group: app:<id>:<timestamp>
  const group = `app:${appId}:${Date.now()}`;
  // Expose for child app scripts if needed
  window.__teAppGroup = group;

  // Persist to shared state (optional, if window.teState is present)
  if (window.teState && typeof window.teState.set === "function") {
    try { window.teState.set(`apps.${appId}.group`, group); } catch {}
  }

  // On pagehide (works for reloads and SPA nav away), tear down shells in this group
  async function terminateGroup() {
    try {
      await fetch("/api/framework_shells/terminate_group", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ group })
      });
    } catch {}
  }
  window.addEventListener("pagehide", terminateGroup, { once: true });
})();
</script>
```

Any app backend that spawns a shell should stamp `TE_GROUP=window.__teAppGroup` in the child’s environment so the **terminate_group** call reaps *all* shells the app created.

---

## 3) Where apps get their HTML/JS

- The **launcher** reads `/api/apps` and builds the grid; clicking an item navigates to `/app/<id>` (full‑screen frame).
- Inside the shell, your existing JS fetches the app’s `frontend_template` and `frontend_script` from `/apps/<_dir>/…` and hydrates the page.

No per‑app code is required for this step; it’s all generic and driven by `manifest.json` fields.

---

## 4) Optional: expose the group to app scripts

If you want app scripts to read the group and pass it along to their own backend calls, they can just read `window.__teAppGroup` from the outer frame. If you embed apps in an iframe for isolation, include a small postMessage handshake to deliver the group to the child frame.

---

## 5) Summary

- **One** backend blueprint powers app discovery, asset serving, and the shell route.
- A tiny **pagehide** hook + **terminate_group** keeps resource cleanup simple.
- Apps remain strictly manifest‑driven; no app‑specific wiring needed.
