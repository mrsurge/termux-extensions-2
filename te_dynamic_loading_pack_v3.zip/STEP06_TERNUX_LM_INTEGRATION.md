# Step 6 — Termux‑LM Integration (Dual Shells + HF Search + Aria Handoff)

**Goal:** Wire the Termux‑LM app so it spawns **two child shells** on demand:
1) a **llama.cpp** `llama-server` for local models, and
2) an **Open Interpreter** server bound to the same model context.
Both are tagged with a **group id** so they cascade-terminate with the app.

---

## 1) Grouping convention for Termux‑LM
Use `group = f"app:termux_lm:{model_id}"` for anything spawned by Termux‑LM for a given model.

- The Open Interpreter helper already builds a label like `oi:{model_id}` and launches via the framework manager; we’ll wrap that spawn call to include group markers.
- The backend controls model load/unload, sessions, and llama.cpp orchestration and is the right place to tag the llama shell with the same group.

## 2) Drop‑in helper usage

**New import in Termux‑LM backend & OI helper**
```diff
--- a/app/apps/termux_lm/backend.py
+++ b/app/apps/termux_lm/backend.py
@@
-from app.framework_shells import _manager as get_framework_shell_manager
+from app.framework_shells import _manager as get_framework_shell_manager
+from app.utils.shell_groups import spawn_scoped_shell, terminate_group
```

### 2a) Tagging the **llama.cpp** shell
Find the place where the backend spawns `llama-server` (in the model **load** path right after `_build_llama_command(model)`), and replace the raw `spawn_shell(...)` with:

```python
mgr = get_framework_shell_manager()
group = f"app:termux_lm:{model['id']}"
cmd = _build_llama_command(model)
label = f"llama:{model['id']}"
record = spawn_scoped_shell(
    mgr,
    command=cmd,
    label=label,
    role="service",
    group=group,
    cwd=str(Path.home()),
    autostart=True,
)
# persist returned shell id in state.json as before
```

### 2b) Tagging the **Open Interpreter** shell
Patch `ensure_interpreter_shell` in `open_interpreter.py` so it stamps the same group:

```diff
--- a/app/apps/termux_lm/open_interpreter.py
+++ b/app/apps/termux_lm/open_interpreter.py
@@
-from app.framework_shells import FrameworkShellManager
+from app.framework_shells import FrameworkShellManager
+from app.utils.shell_groups import spawn_scoped_shell
@@ def ensure_interpreter_shell(manager: FrameworkShellManager, model: Dict[str, Any]) -> Dict[str, Any]:
-    command_info = build_interpreter_command(model)
-    record = manager.spawn_shell(
-        command_info["command"],
-        cwd=str(Path.home()),
-        label=label,
-        env=command_info["env"],
-        autostart=True,
-    )
+    command_info = build_interpreter_command(model)
+    group = f"app:termux_lm:{model['id']}"
+    record = spawn_scoped_shell(
+        manager,
+        command=command_info["command"],
+        cwd=str(Path.home()),
+        label=label,
+        role="service",
+        group=group,
+        env=command_info["env"],
+        autostart=True,
+    )
     description = manager.describe(record)
     return {"record": description, "created": True}
```

### 2c) Cascade teardown on unload
In the model **unload** handler (or when deleting a model), terminate the whole group so both child shells die together:

```diff
--- a/app/apps/termux_lm/backend.py
+++ b/app/apps/termux_lm/backend.py
@@
 def _terminate_shell(manager, shell_id: str) -> None:
     try:
         manager.remove_shell(shell_id, force=True)
     except KeyError:
         pass
     except Exception as exc:
         current_app.logger.warning("termux_lm: failed to terminate shell %s: %s", shell_id, exc)
+
+def _terminate_model_group(manager, model_id: str) -> int:
+    group = f"app:termux_lm:{model_id}"
+    try:
+        return terminate_group(manager, group, force=True)
+    except Exception:
+        return 0
```

Then call `_terminate_model_group(get_framework_shell_manager(), model_id)` from your unload/delete endpoints. The rest of your state cleanup is unchanged.

---

## 3) Hugging Face search + Aria2 handoff (already in place)
- Keep your `.gguf`-only HF search helper; no changes required.
- Frontend already ensures the Aria downloader service is running, posts an `add` request, and redirects to the downloader app.
- The minimal Aria JSON‑RPC client is fine as-is.

---

## 4) Termux‑LM anatomy (for reference)
- `manifest.json` declares the backend, template, and script entrypoints.
- `template.html` lays out the status header, shell logs, model cards, modals, chat overlay, etc.
- `style.css` holds `tlm-*` component styles.
- `backend.py` provides the REST API, persistence, streaming chat for local/remote models.
- `main.js` drives UI logic, HF search modal, file picker, Aria handoff, model/session lifecycle, and chat.
- Maintainer docs: overview + working notes live with the app.

---

## 5) Optional parent breadcrumb
If you have an app-shell process id to tag, pass `parent=<app_shell_id>` to `spawn_scoped_shell(...)` to record `TE_PARENT`.
