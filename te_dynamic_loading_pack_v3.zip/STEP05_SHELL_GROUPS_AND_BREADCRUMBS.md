# Step 5 — Shell Groups, Roles & Breadcrumbs (Framework‑Only)

**Goal:** Mark every spawned shell with **who owns it** (group), **what it is** (role), and optionally **who spawned it** (parent). Then add a tiny function to **tear down an entire group** gracefully when the owning app closes or errors.

## New helper
- `app/utils/shell_groups.py` — one small wrapper and a group terminator.

```python
# app/utils/shell_groups.py
from __future__ import annotations
from typing import Dict, Optional, Any, List

def _merge_env(base: Optional[Dict[str, str]], extra: Optional[Dict[str, str]]) -> Dict[str, str]:
    out = dict(base or {})
    out.update(extra or {})
    return out

def spawn_scoped_shell(manager, *, command: List[str], label: str,
                       role: str, group: str, parent: Optional[str] = None,
                       cwd: Optional[str] = None, env: Optional[Dict[str, str]] = None,
                       autostart: bool = True, **kwargs: Any):
    env_markers = { "TE_ROLE": role, "TE_GROUP": group }
    if parent: env_markers["TE_PARENT"] = parent
    env_final = _merge_env(env, env_markers)
    return manager.spawn_shell(command, cwd=cwd, label=label, env=env_final, autostart=autostart, **kwargs)

def terminate_group(manager, group: str, *, force: bool = True) -> int:
    """Terminate all shells whose env TE_GROUP matches 'group'. Returns count."""
    count = 0
    for record in manager.list_shells():
        desc = manager.describe(record) or {}
        env = desc.get("env") or {}
        if env.get("TE_GROUP") == group:
            try:
                manager.terminate_shell(desc.get("id"), force=force)
                count += 1
            except Exception:
                pass
    return count
```

## Minimal Supervisory Hook (optional)
Add a route somewhere you already expose framework operations:

```python
# app/admin_shells.py  (example)
from flask import Blueprint, jsonify, request
from app.framework_shells import _manager as get_mgr
from app.utils.shell_groups import terminate_group

bp = Blueprint("admin_shells", __name__)

@bp.post("/api/framework_shells/terminate_group")
def api_terminate_group():
    payload = request.get_json(silent=True) or {}
    group = (payload.get("group") or "").strip()
    if not group:
        return jsonify({"ok": False, "error": "group is required"}), 400
    mgr = get_mgr()
    n = terminate_group(mgr, group, force=True)
    return jsonify({"ok": True, "data": {"terminated": n}})
```

**Breadcrumb →** `STEP06_TERNUX_LM_INTEGRATION.md`
