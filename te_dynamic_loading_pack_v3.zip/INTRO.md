# Dynamic App Loading & Failure Containment — Implementation Guide (v3, generic)

This pack hardens your framework so **broken app modules never crash the server**, and heavy/fragile deps **load on demand** with safe fallbacks. v3 removes app‑specific examples and documents a **generic, manifest‑driven Apps integration** that works for all apps loaded by the Apps extension.

**Scope**
- Non‑fatal dynamic loading for apps *and* extensions
- Conditional/optional imports inside endpoints
- Fallback to per‑app workers when imports are missing or unsafe
- Job isolation patterns (attach/cancel/stream)
- **Shell groups & roles** (`TE_ROLE`, `TE_GROUP`, `TE_PARENT`) for cascade teardown
- **Generic Apps extension integration** (manifest‑driven list → app shell → asset serving → lifecycle hooks)

**How to use this pack**
1. Apply **Step 1** (safe dynamic imports in core loader).
2. Add **Step 2** (optional/conditional imports utility).
3. Use **Step 3** for worker fallbacks (spawn on demand; idle reaper).
4. Adopt **Step 4** for job isolation/attachment.
5. Add **Step 5** to tag shells with groups/roles and expose a terminate‑group endpoint.
6. Implement **Step 6** to wire the generic Apps extension backend and minimal app‑shell JS lifecycle hooks.

**Breadcrumb to the next doc →** `STEP01_NON_FATAL_LOADER.md`
