#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "$0")"/.. && pwd)"
BASE="${ROOT_DIR}/app/static/vendor/codemirror/@codemirror"
PKGS=(state view commands search language lang-javascript lang-json lang-python lang-html lang-css lang-markdown lang-shell lang-xml)

WORKDIR=$(mktemp -d)
pushd "$WORKDIR" >/dev/null
npm init -y >/dev/null 2>&1
npm i @codemirror/state @codemirror/view @codemirror/commands @codemirror/search @codemirror/language       @codemirror/lang-javascript @codemirror/lang-json @codemirror/lang-python @codemirror/lang-html       @codemirror/lang-css @codemirror/lang-markdown @codemirror/lang-shell @codemirror/lang-xml       --no-audit --no-fund --silent

for p in "${PKGS[@]}"; do
  mkdir -p "$BASE/$p/dist"
  cp -r "node_modules/@codemirror/$p/dist"/* "$BASE/$p/dist/" || true
  if [ -d "node_modules/@codemirror/$p/style" ]; then
    mkdir -p "$BASE/$p/style"
    cp -r "node_modules/@codemirror/$p/style"/* "$BASE/$p/style/"
  fi
done

popd >/dev/null
rm -rf "$WORKDIR"
echo "CodeMirror 6 vendored into $BASE"
